#include "stdafx.h"
#include "Question.h"

//These method has been defined from class.cpp

Question::Question() 
{

}

Question::Question(string input)
{
	qValue = input;
}

string Question::getQuestion()
{
	return qValue;
}

void Question::setQuestion(string question)
{
	qValue = question;
}

int Question::binSearch(string name, vector<Question> table) 
{
	/*
	Initialise first to 0, length to the table's size (size of question array)
	and last by the last number of the element of the array
	*/

	int first = 0;

	int length = table.size();

	int last = length - 1;

	//These two for loops allows to match the keywords to the questions easily

	//Go through every character of user input and convert to lowercase
	for (int character = 0; character < name.size(); character++)
	{
		name[character] = tolower(name[character]);
	}

	//Go through every elements in an array and convert to lowercase
	for (int value = 0; value < length; value++)
	{
		string cases = table[value].qValue;

		for (int characters = 0; characters < cases.size(); characters++)
		{
			cases[characters] = tolower(cases[characters]);
		}

		table[value] = cases;

	}

	//Continue until first is greater than last
	while (first <= last)
	{
		//Split the array into two to identify the middle in the binary tree
		int middle = (first + last) / 2;

		/*
		Start from the first character until the length of name from table[middle] and compare,
		if the first few characters match with name, result will be 0, if alphabetically,
		name is first and then table[middle], result will be 1, otherwise, result
		will be -1.
		*/

		int result = strncmp(table[middle].qValue.c_str(), name.c_str(), name.size());

		/*
		If result less than 0, set first by increment middle by 1, only the first half
		are declare to check.
		*/

		if (result < 0)
		{
			first = middle + 1;
		}

		/*
		If result greater than 0, set last by decrement middle by 1, only the last half
		are declare to check.
		*/

		else if (result > 0)
		{
			last = middle - 1;
		}

		//If result equals to 0, return middle for decalring that first result have been found

		else
		{
			return middle;
		}

	}

	//If the binary search has not succeed searching, then do a linear search for each questions
	for (int position = 0; position < table.size(); position++)
	{
		//If the user input has contains in the array, return this position
		if (table[position].qValue.find(name) != string::npos)
		{
			return position;
		}
	}


	return -1; // name is not in table[]
}

