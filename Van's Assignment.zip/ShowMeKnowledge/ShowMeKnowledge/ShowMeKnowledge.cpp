// ShowMeKnowledge.cpp : Defines the entry point for the console application.
//

/*
Creator Name:

Van Do

Creation Date:

6 February 2017

Description of what the Application does:

This application allows the user to get the file and letting the system to sort. Also, this system
allows user to search for the question using keywords to find the answer. Completed (27/02/2017)

*/

#include "stdafx.h" //Allows the application to works
#include <fstream> //Use for open file and write file
#include <string> //Use for accepting the string variable
#include <algorithm> //Use for sorting array and binary search
#include <vector> //Use for vector that allows to sort and search array easily
#include "Question.h" //Use the header file contains Question class

using namespace std; //Use for cin, cout and string

/*
	When using cin.clear(), it will clear out the memory of every user input
*/

//Sort 2D array using vector by pass-by-reference of the vectors
bool sortVector(vector<Question> &lhs, vector<Question> &rhs)
{
	//Return if the left hand side of the vector's element is less than the right hand side = true or false
	return lhs[0].getQuestion() < rhs[0].getQuestion();
}

int main()
{
	//Set counting as integer
	float continuing;
	//Set line as string for checking line in a file
	string line;
	//For valid user press enter to continue
	string enter;
	//Set object as question object
	Question object = Question();

	//Store question and answer into a vector
	vector<vector<Question>> twoArray;

	//Display the instruction to get file from 

	cout << "This program allows to sort all of your questions and search for answers from the file." << endl;

	cout << "You can only use one file for this application." << endl;

	cout << "Enter file name (eg. example.txt): ";

	string fileName;

	//Get a line of input and set the line from fileName
	getline(cin, fileName);

	//Read the text file using binary file
	ifstream file(fileName, ios::in, ios::binary);

	cin.clear();

	//Set 2d array of question object array, set rows to 10 and cols to 2 for question and answer

	cout << endl << "Set the number of questions and answers in array." << endl;

	cout << "Whatever number you input will be round down. For example (Between 3 and 4, the value will be 3)." << endl;

	cout << "If there are letters after number for trying to input number, the letters will be truncate." << endl;

	cout << "Make sure that all questions have same number of answers." << endl << endl;

	//Allows the user to enter the number of questions, assuming questions are length

	float length;

	do 
	{
		cout << "Enter the length of array (number of questions): ";

		cin >> length;

		//If user have not input integer, repeat this process
		while (cin.fail())
		{
			cin.clear();
			cin.ignore(80, '\n');
			cout << "Must be a number." << endl;
			cout << "Enter the number of questions: ";
			cin >> length;
		}

		//Check if the number of questions is less than 1, then repeat this process again
		if (length < 1) 
		{
			cout << "The number of elements for rows must be greater than 0." << endl;
			cout << "Cannot have empty question." << endl;
		}

	} while (length < 1);

	//When length is confirm, set the user input as length

	/*
		Allows the user to enter the number of answers, however the user must add one because
		2d array must include question and answers. Therefore, column 0 is question while the rests are
		answers.
	*/

	//If there are decimal from user input, round it down
	length = floor(length);

	//Assuming width is answer including one question
	float width;

	//Similar to length, expect set for columns of array
	do 
	{
		cout << "Enter the width of array (number of answers + 1): ";

		cin >> width;

		while (cin.fail())
		{
			cin.clear();
			cin.ignore(80, '\n');
			cout << "Must be a number." << endl;
			cout << "Enter the number of answers + 1: ";
			cin >> width;
		}

		//Check if the user input is less than 2, then repeat this process again
		if (width < 2) 
		{
			cout << "The number of elements for columns must be greater than 1." << endl;
			cout << "Columns must included the number of answers and one question." << endl;
		}

	} while (width < 2);

	//If there are decimal from user input, round it down
	width = floor(width);

	//Multiply the length and width to get elements, so that validate the number of lines in the file
	int elements = static_cast<int>(length) * static_cast<int>(width);

	//Set the array for qObject as pointer to set the length as user input
	Question **qObject = new Question*[length];

	//Add another array for qObject to make 2d array
	for (int count = 0; count < length; ++count)
	{
		qObject[count] = new Question[width];
	}

	//Resize the vector length to 10
	twoArray.resize(length);

	//Resize each of element's columns by 2
	for (int count = 0; count < length; count++)
	{
		twoArray[count].resize(width);
	}
	
	//Check if this file does not exist or cannot be open, display this message and repeat the application again
	if (!file.is_open())
	{
		cout << "Couldn't open file" << endl << endl;
		cin.clear();
		cin.ignore();
		main();
	}

	//If file can be open, do this condition
	else
	{
		cout << "File open success..." << endl << endl;

		//Set counting to 0
		int counting = 0;

		//Go through every line and increment counting by 1
		while (!file.eof()) 
		{
			getline(file, line);
			counting++;
		}

		//Move from the start of the file to avoid close and reopen file using random access
		file.seekg(0, ios::beg);

		//If the elements are greater than the number of lines, repeat the application again
		if (elements > counting) 
		{
			cout << "The set rows and columns multiply together are too big." << endl;
			cout << "There are only " << counting << " elements not " << elements << "." << endl;
			cout << "Please check your files and make sure the number of lines equals to the number of elements." << endl;
			cout << "Press enter to repeat process again." << endl;
			cin.clear();
			cin.ignore();
			cin.get();
			main();
		}

		//If the elements are less than the number of lines, repeat the application again
		else if (elements < counting)
		{
			cout << "The set rows and columns multiply together are too small." << endl;
			cout << "There are only " << counting << " elements not " << elements << "." << endl;
			cout << "Please check your files and make sure the number of lines equals to the number of elements." << endl;
			cout << "Press enter to repeat process again." << endl;
			cin.clear();
			cin.ignore();
			cin.get();
			main();
		}

		//Continuing adding line to the array while it does not reach to the end of the line
		while (!file.eof())
		{
			//Add to 2D array from row 0 to max row
			for (int row = 0; row < length; row++)
			{
				//For every line add to 2D array from col 0 to max col
				//Manipulate 2D array by reading file and add line from file to array
				for (int col = 0; col < width; col++)
				{
					//Get the line from file and set to line
					getline(file, line);
					//Add line to question array
					qObject[row][col] = Question(line);
					//Add question array to vector
					twoArray[row][col] = qObject[row][col];

				}
			}
		}
	}

	//Close this file
	file.close();

	//Sort 2d array

	//Sort the array using algorithm and the method 'sortVector'
	sort(twoArray.begin(), twoArray.end(), sortVector);

	//Store question into this array for binary search
	vector<Question> questions;

	questions.resize(length);

	for (int rows = 0; rows < twoArray.size(); rows++) 
	{
		questions[rows] = twoArray[rows][0].getQuestion();
	}

	//Proceed to searching for array
	cout << "Sorting questions completed..." << endl;
	cout << "Search for question and answer..." << endl << endl;

	//Set notFound to 0
	int notFound = 0;
	
	//Allows the user to search for the number of times
	cout << "How many times do you want to search for? ";

	//User enters the number of times that the user wants to search
	cin >> continuing;

	//If the user have not input integer, repeat this step
	while (cin.fail()) 
	{
		cin.clear();
		cin.ignore(80, '\n');
		cout << "Must be an integer." << endl;
		cout << "How many times do you want to search for? ";
		cin >> continuing;
	}

	//If there are decimal from user input, round it down
	continuing = floor(continuing);

	cout << endl << "You are going to search for " << continuing << " times." << endl;

	//Go through each search
	for (int count = 0; count < continuing; count++)
	{
		//Display this message if the user wants to search more than once
		if (count < continuing)
		{
			//To avoid user pressed enter twice, add this variable to proceed by only press enter once
			int valid = 0;

			//Continue this while user have not press enter only
			do
			{
				//If this is the start of the loop, clear and ignore cin
				if (count == 0 && valid == 0) 
				{
					cin.clear();
					cin.ignore(80, '\n');
				}

				//Display this message so that the user press enter to continue
				cout << "Press enter only to continue..." << endl;
				//Get user input and it must be only pressing enter key
				getline(cin, enter);
				//Set valid to 1 to avoid press enter twice
				valid = 1;

			} while (enter != "");

		}

		//Allocate the user to enter keywords to search for questions to find answers
		cout << "Which question do you want to search for? ";

		//Set search as string
		string search;

		//Get the line of input and set for search
		getline(cin, search);

		cout << endl;

		int find = object.binSearch(search, questions);

		//Check if binary search have found the keyword from the question's array
		if (find != -1)
		{
			cout << "First result found at element " << find << endl;

			for (int column = 0; column < width; column++) 
			{
				//Display the questions and answers from the keyword
				cout << twoArray[find][column].getQuestion() << endl;
			}
			
		}

		//If the keyword have not compared every questions, display not found
		else
		{
			cout << "'" << search << "' not found!" << endl;
		}

		cout << endl;

	}

	//After finishing search, user must press enter only to continue to next step
	do
	{
		cout << "Press enter only to continue..." << endl;
		getline(cin, enter);

	} while (enter != "");

	cin.clear();

	cout << endl << "Display sorted array..." << endl << endl;

	//Display sorted array from system
	for (int rows = 0; rows < length; rows++)
	{
		for (int cols = 0; cols < width; cols++)
		{
			cout << twoArray[rows][cols].getQuestion() << endl;
		}

		cout << endl;
	}

	cin.clear();

	//Release memory allocate from qObject's column
	for (int count = 0; count < length; count++) 
	{
		delete[] qObject[count];
	}

	//Release memory allocate from qObject
	delete[] qObject;

	//qObject becomes null pointer
	qObject = nullptr;

	//User must press enter to close this program or close the application
	cout << endl << "Press enter to exit or close the application...";

	cin.ignore();

	exit(0);

    return 0;
}



