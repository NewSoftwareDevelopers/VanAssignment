#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Question
{
	//Privatise the variable
	private:
		string qValue; //Value can be a question or answer

	//Publicise the method for source file to access
	public:

		//These method has been left as declaration.

		//Null constructor
		Question();
		//Parameterised constructor, set qValue by the file line
		Question(string input);
		//However, the getters are the only method that can be used for the source code
		//Getters
		string getQuestion();
		//Setters
		void setQuestion(string question);
		//This method allows to use binary search and return the found element
		int binSearch(string name, vector<Question> table);
};

